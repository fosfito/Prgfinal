let nro;
nro=prompt("Ingrese un numero positivo mayor a cero");
for (let i = nro; i > 0; i--) {
    alert(i);
    
}
alert("BOOOM");