let nro=0;
let piramide=" ";
nro=prompt("Ingrese un valor menor a 50");
for (let i = 1; i <= nro; i++) {
    piramide=piramide+i; 
    console.log(piramide);
    }
