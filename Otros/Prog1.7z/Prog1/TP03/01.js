let numero=1;
//alert("hola");
numero=prompt("Ingrese un numero, 0 corta");
while(numero!=0){
    numero=prompt("Ingrese un numero, 0 corta");
    }