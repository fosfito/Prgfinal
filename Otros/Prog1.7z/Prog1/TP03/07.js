let palabra=" ";
let i=-1;
while (palabra!="fin") {
        palabra=prompt("Ingrese una palabra: ");
        i++;
}
console.log("Se ingresaron "+i+" palabras.");