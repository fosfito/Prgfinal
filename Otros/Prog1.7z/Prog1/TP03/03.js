let rdo=" ";
for (let i = 500; i <= 1000; i=i+2) {
 rdo=rdo+"-"+i;
    //console.log(i);
}
alert(rdo);
